package com.caiyu.personal_blog.controller;

import com.caiyu.personal_blog.service.CommentInfoService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
public class CommentController {
    @Resource
    private CommentInfoService commentInfoService;

/*    @RequestMapping("/search_by_user")
    public List<Map<String,Object>> findCommentByUser(@RequestParam Map<String,String> map){
        List<Map<String,Object>> list=commentInfoService.doFindCommentByUser(map);
        return list;
    }*/

    @RequestMapping("/getcomments")
    public List<Map<String,Object>> findCommentByBlog(@RequestParam Map<String,String> map){
        List<Map<String,Object>> list=commentInfoService.doFindCommentByBlog(map);
        return list;
    }

    @RequestMapping("/addcomments")
    public String addComment(@RequestParam Map<String,String> map){
        String msg="0";
        boolean flag=commentInfoService.doAddComment(map);
        if(flag){
            msg="1";
        }
        return msg;
    }

 /*   @RequestMapping("/delete1")
    public String deleteComment(@RequestParam Map<String,String> map){
        String msg="删除失败";
        boolean flag=commentInfoService.doDeleteComment(map);
        if(flag){
            msg="删除成功";
        }
        return msg;
    }

    @RequestMapping("/likes1")
    public int getCommentLikes(@RequestParam Map<String,String> map){
        return commentInfoService.doSearchCommentLikes(map);
    }

    @RequestMapping("/updatelikes1")
    public String updateCommentLikes(@RequestParam Map<String,String> map){
        String msg="点赞失败";
        boolean flag=commentInfoService.doUpdateCommentLikes(map);
        if(flag){
            msg="点赞成功";
        }
        return msg;
    }*/
}
