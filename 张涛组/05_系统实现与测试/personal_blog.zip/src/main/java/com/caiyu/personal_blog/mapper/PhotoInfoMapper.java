package com.caiyu.personal_blog.mapper;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface PhotoInfoMapper {
    //添加照片
    @Insert("INSERT INTO photos (photo_type,photo_description,photo_path) " +
            "VALUE(#{photo_type},#{photo_description},#{photo_path})")
    public int addPhoto(Map<String,String> map);

    //查找照片墙所有信息
    @Select("select * from photos ")
    public List<Map<String,Object>> findAllPhoto();

    //根据照片id删除留言
    @Delete("delete from photos where photo_id=#{photo_id}")
    public int deletePhoto(int id);

}
