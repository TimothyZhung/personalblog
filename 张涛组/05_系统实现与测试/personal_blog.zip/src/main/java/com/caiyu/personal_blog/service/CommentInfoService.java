package com.caiyu.personal_blog.service;

import com.caiyu.personal_blog.mapper.CommentInfoMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class CommentInfoService {
    @Resource
    private CommentInfoMapper commentInfoMapper;

    public List<Map<String,Object>> doFindCommentByUser(Map<String,String> map) {
        List<Map<String, Object>> list = null;
        try {
            list = commentInfoMapper.findCommentByUserID(Integer.parseInt(map.get("user_id")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Map<String,Object>> doFindCommentByBlog(Map<String,String> map) {
        List<Map<String, Object>> list = null;
        try {
            list = commentInfoMapper.findCommentByBlogID(Integer.parseInt(map.get("blog_id")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean doAddComment(Map<String,String> map){
        boolean flag=false;
        map.put("comment_likes","0");
        //选择要添加监控的代码
        //ctrl+alt+t 打开 surround with窗口 选择 try catch
        try {
            int r=commentInfoMapper.addComment(map);
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //记录日志，写到文件中进行保存
        }
        return flag;
    }

    public boolean doDeleteComment(Map<String,String> map){
        boolean flag=false;
        try {
            int r=commentInfoMapper.deleteComment(Integer.parseInt(map.get("id")));
            if(r>0){
                flag=true;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public int doSearchCommentLikes(Map<String,String> map){
        int likes=0;
        try {
            likes = commentInfoMapper.searchCommentLikes(Integer.parseInt(map.get("blog_id")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return likes;
    }

    public boolean doUpdateCommentLikes(Map<String,String> map){
        boolean flag=false;
        try {
            int r=commentInfoMapper.updateCommentLikes(map);
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }
}
