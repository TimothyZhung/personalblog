package com.caiyu.personal_blog.mapper;

import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface MessageInfoMapper {

    //添加留言
    @Insert("INSERT INTO messages (user_id,message_name,message_email,message_content,message_time) " +
            "VALUE(#{user_id},#{message_name},#{message_email},#{message_content},#{message_time})")
    public int addMessage(Map<String,String> map);

    //查找留言板所有信息
    @Select("select * from messages ")
    public List<Map<String,Object>> findAllMessage();

    //根据留言id删除留言
    @Delete("delete from messages where message_id=#{message_id}")
    public int deleteMessage(int id);

}
