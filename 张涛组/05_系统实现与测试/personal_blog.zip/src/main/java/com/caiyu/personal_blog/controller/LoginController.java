package com.caiyu.personal_blog.controller;


import com.caiyu.personal_blog.service.LoginInfoService;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Map;

@CrossOrigin
@RestController
public class LoginController {
    @Resource
    private LoginInfoService loginInfoService;

    //先检查邮箱是否存在,不存在返回"用户不存在";再检查密码是否正确,正确则返回用户id
    @RequestMapping("/login")
    public String login(@RequestParam Map<String,String> map){
        String msg="登陆失败";
        if (!loginInfoService.checkEmail(map)){
            msg="none";
        }
        else {
            if(loginInfoService.checkLogin(map)!=null){
                msg=String.valueOf(loginInfoService.checkLogin(map).get("user_id"));
            }
            else{
                msg="error";
            }
        }
        return msg;
    }

}
