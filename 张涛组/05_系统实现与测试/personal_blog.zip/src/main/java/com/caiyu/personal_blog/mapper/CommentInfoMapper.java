package com.caiyu.personal_blog.mapper;

import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface CommentInfoMapper {
    //通过用户的id查询
    @Select("select * from comments where user_id=#{user_id}")
    public List<Map<String,Object>> findCommentByUserID(int user_id);

    //通过博客的id查询
    @Select("select * from comments where blog_id=#{blog_id}")
    public List<Map<String,Object>> findCommentByBlogID(int blog_id);

    //添加评论 comment_content不可以为空      评论点赞数刚开始为0
    @Insert("insert into comments (blog_id,user_id,comment_likes,"+
            "comment_time,comment_content,comment_parent_id) "+
            "value(#{comment.blog_id},#{comment.user_id},#{comment.comment_likes},"+
            "#{comment.comment_time},#{comment.comment_content},#{comment.comment_parent_id})")
    public int addComment(@Param("comment") Map<String,String> map);

    //根据评论的id号 删除该评论
    @Delete("delete from comments where comment_id=#{comment_id}")
    public int deleteComment(int id);

    //根据评论id号 查询评论点赞数
    @Select("select comment_likes from comments where comment_id=#{comment_id}")
    public int searchCommentLikes(int id);

    //根据评论的id号 更新评论点赞数使其+1
    @Update("update comments " +
            "set comment_likes=comment_likes+1 " +
            "where comment_id=#{comment.id}")
    public int updateCommentLikes(@Param("comment") Map<String,String> map);
}
