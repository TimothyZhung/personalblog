package com.caiyu.personal_blog.service;


import com.caiyu.personal_blog.mapper.LoginInfoMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;


@Service
public class LoginInfoService {
    @Resource
    private LoginInfoMapper loginInfoMapper;

    public boolean checkEmail(Map<String,String> map){
        boolean flag=false;
        Map<String,String> info=null;
        try {
            info=loginInfoMapper.findUserEmail(map.get("email"));
            if(info!=null && info.size()>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //记录日志，写到文件中进行保存
        }
        return flag;
    }

    //判断邮箱密码是否匹配
    public Map<String,String> checkLogin(Map<String,String> map){
        Map<String,String> info=null;
        try{
            info=loginInfoMapper.findLoginInfo(map);
        }catch (Exception ex){

        }
        return info;
    }
}
