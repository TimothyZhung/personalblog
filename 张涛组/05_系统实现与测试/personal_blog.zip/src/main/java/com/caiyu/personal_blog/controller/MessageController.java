package com.caiyu.personal_blog.controller;

import com.caiyu.personal_blog.mapper.MessageInfoMapper;
import com.caiyu.personal_blog.service.MessageInfoService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
public class MessageController {
    @Resource
    private MessageInfoService messageInfoService;

    @RequestMapping("/sendmess")
    public String addBlog(@RequestParam Map<String,String> map){
        String msg="0";
        boolean flag=messageInfoService.doAddMessage(map);
        if(flag){
            msg="1";
        }
        return msg;
    }

    @RequestMapping("/getmess")
    public List<Map<String,Object>> findAllMessage(){
        List<Map<String,Object>> list=messageInfoService.doFindAllMessage();
        return list;
    }

    @RequestMapping("/deletemess")
    public String deleteMessage(@RequestParam Map<String,String> map){
        String msg="0";
        boolean flag=messageInfoService.doDeleteMessage(map);
        if(flag){
            msg="1";
        }
        return msg;
    }
}
