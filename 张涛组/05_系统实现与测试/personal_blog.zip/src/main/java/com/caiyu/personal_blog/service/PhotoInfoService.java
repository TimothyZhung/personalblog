package com.caiyu.personal_blog.service;

import com.caiyu.personal_blog.mapper.PhotoInfoMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class PhotoInfoService {
    @Resource
    private PhotoInfoMapper photoInfoMapper;

    public boolean doAddPhoto(Map<String,String> map){
        boolean flag=false;
        //选择要添加监控的代码
        //ctrl+alt+t 打开 surround with窗口 选择 try catch
        try {
            int r=photoInfoMapper.addPhoto(map);
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //记录日志，写到文件中进行保存
        }
        return flag;
    }

    public List<Map<String,Object>> doFindAllPhoto(){
        List<Map<String, Object>> list = null;
        try {
            list = photoInfoMapper.findAllPhoto();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean doDeletePhoto(Map<String,String> map){
        boolean flag=false;
        try {
            int r=photoInfoMapper.deletePhoto(Integer.parseInt(map.get("photo_id")));
            if(r>0){
                flag=true;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return flag;
    }
}
