package com.caiyu.personal_blog.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Map;

@Mapper
public interface SignupInfoMapper {
    //查找输入邮箱
    @Select("select user_email from users"+
            " where user_email=#{email}")
    public Map<String,String> findUserEmail(String email);

    //向数据库中添加注册信息
    @Insert("insert into users(user_email,user_password)" +
            "value(#{u.email},#{u.password})")
    public int save(@Param("u") Map<String,String> map);

    //通过用户id查找用户邮箱
    @Select("select user_email from users"+
            " where user_id=#{user_id}")
    public String searchEmail(int user_id);

}
