package com.caiyu.personal_blog.service;

import com.caiyu.personal_blog.mapper.MessageInfoMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MessageInfoService {
    @Resource
    private MessageInfoMapper messageInfoMapper;

    public boolean doAddMessage(Map<String,String> map){
        boolean flag=false;
        //选择要添加监控的代码
        //ctrl+alt+t 打开 surround with窗口 选择 try catch
        try {
            int r=messageInfoMapper.addMessage(map);
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //记录日志，写到文件中进行保存
        }
        return flag;
    }

    public List<Map<String,Object>> doFindAllMessage(){
        List<Map<String, Object>> list = null;
        try {
            list = messageInfoMapper.findAllMessage();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean doDeleteMessage(Map<String,String> map){
        boolean flag=false;
        try {
            int r=messageInfoMapper.deleteMessage(Integer.parseInt(map.get("message_id")));
            if(r>0){
                flag=true;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return flag;
    }
}
