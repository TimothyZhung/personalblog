package com.caiyu.personal_blog.controller;

import com.caiyu.personal_blog.service.BlogInfoService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
public class BlogController {
    @Resource
    private BlogInfoService blogInfoService;


    @RequestMapping("/getallblogs")
    public List<Map<String,Object>> findBlogByUser(){
        List<Map<String,Object>> list=blogInfoService.doFindBlogByUser();
        return list;
    }

    @RequestMapping("/getblog")
    public Map<String, Object> getBlogDetails(@RequestParam Map<String,String> map){
        Map<String, Object> info = new HashMap<String, Object>();
        info=blogInfoService.doFindBlogByBlogID(map);
        if(blogInfoService.doFindIfLiked(map)){
            info.put("ifliked","1");
        }
        else{
            info.put("ifliked","0");
        }
        return info;
    }



    @RequestMapping("/upblog")
    public String addBlog(@RequestParam Map<String,String> map){
        String msg="0";
        boolean flag=blogInfoService.doAddBlog(map);
        if(flag){
            msg="1";
        }
        return msg;
    }

    @RequestMapping("/saveblog")
    public String changeBlog(@RequestParam Map<String,String> map){
        String msg="0";
        boolean flag=blogInfoService.doChangeBlog(map);
        if(flag){
            msg="1";
        }
        return msg;
    }

    @RequestMapping("/deleteblog")
    public String deleteBlog(@RequestParam Map<String,String> map){
        String msg="0";
        boolean flag=blogInfoService.doDeleteBlog(map);
        if(flag){
            msg="1";
        }
        return msg;
    }

/*    @RequestMapping("/views")
    public int getBlogViews(@RequestParam Map<String,String> map){
        return blogInfoService.doSearchBlogViews(map);
    }

    @RequestMapping("/updateviews")
    public String updateBlogViews(@RequestParam Map<String,String> map){
        String msg="浏览量+1失败";
        boolean flag=blogInfoService.doUpdateBlogViews(map);
        if(flag){
            msg="浏览量+1成功";
        }
        return msg;
    }

    @RequestMapping("/likes")
    public int getBlogLikes(@RequestParam Map<String,String> map){
        return blogInfoService.doSearchBlogLikes(map);
    }*/

    @RequestMapping("/changelikes")
    public String changeBlogLikes(@RequestParam Map<String,String> map){
        String msg="0";
        if(blogInfoService.doFindIfLiked(map)){
            if(blogInfoService.doRegretBlogLikes(map)&&blogInfoService.doDeleteLikeInfo(map)) {
                msg = "1";
            }
        }
        else{
            if(blogInfoService.doUpdateBlogLikes(map)&&blogInfoService.doAddLikeInfo(map)){
                msg = "1";
            }
        }
        return msg;
    }



/*    @RequestMapping("/comments")
    public int getBlogComments(@RequestParam Map<String,String> map){
        return blogInfoService.doSearchBlogComments(map);
    }

    @RequestMapping("/updatecomments")
    public String updateBlogComments(@RequestParam Map<String,String> map){
        String msg="点赞失败";
        boolean flag=blogInfoService.doUpdateBlogComments(map);
        if(flag){
            msg="点赞成功";
        }
        return msg;
    }*/
}
