package com.caiyu.personal_blog.controller;

import com.caiyu.personal_blog.service.PhotoInfoService;
//import org.apache.tomcat.jni.File;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@CrossOrigin
@RestController
@Configuration
public class PhotoController implements WebMvcConfigurer{
    @Autowired
    private HttpServletRequest request;

    @Resource
    private PhotoInfoService photoInfoService;

    @RequestMapping("/upphotos")
    public String addPhoto(@RequestParam String type,@RequestParam String description,@RequestParam MultipartFile file) throws IOException {
        String msg="0";
        boolean flag=false;
        Map<String,String> photo= new HashMap<>();
        photo.put("photo_type",type);
        photo.put("photo_description",description);
        String path = "C:/Users/11585/Pictures/photosWall/";
        String fileName = file.getOriginalFilename();
        String suffixName=fileName.substring(fileName.lastIndexOf("."));
        fileName= UUID.randomUUID()+suffixName;
        File targetFile = new File(path);
        if (!targetFile.exists()) {
            targetFile.mkdirs();
        }
        File saveFile = new File(targetFile, fileName);
        try {
            file.transferTo(saveFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
        photo.put("photo_path",path+fileName);
        flag=photoInfoService.doAddPhoto(photo);
        if(flag){
            msg="1";
        }
        return msg;
    }

    @RequestMapping("/getphotos")
    public List<Map<String,Object>> findAllPhoto(){
        List<Map<String,Object>> list=photoInfoService.doFindAllPhoto();
        return list;
    }

    @RequestMapping("/deletephotos")
    public String deletePhoto(@RequestParam Map<String,String> map){
        String msg="0";
        boolean flag=photoInfoService.doDeletePhoto(map);
        if(flag){
            msg="1";
        }
        return msg;
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/photosWall/**").addResourceLocations("file:C:/Users/11585/Pictures/photosWall/");
    }
}



