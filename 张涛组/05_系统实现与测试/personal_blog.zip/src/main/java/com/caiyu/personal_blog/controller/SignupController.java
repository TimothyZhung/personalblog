package com.caiyu.personal_blog.controller;

import com.caiyu.personal_blog.service.SignupInfoService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Map;

@CrossOrigin
@RestController
public class SignupController {
    @Resource
    SignupInfoService signupInfoService;
    @RequestMapping("/register")
    public String save(@RequestParam Map<String,String> map){
        String msg="注册失败";
        if(map.get("email")==""){
            msg="用户名不能为空";
        }
        else if(!signupInfoService.checkEmail(map)) {
            if(signupInfoService.doSave(map)){
                msg="1";
            }
            else{
                msg="注册失败";
            }
        }
        else {
            msg="用户已存在";
        }
        return msg;
    }

    @RequestMapping("/getemail")
    public String getEmail(@RequestParam Map<String,String> map){
        return signupInfoService.doSearchEmail(Integer.parseInt(map.get("user_id")));
    }
}
