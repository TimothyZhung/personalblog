package com.caiyu.personal_blog.mapper;
/*
用户登录
*/

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.Map;

@Mapper
public interface LoginInfoMapper {
    //查找邮箱是否存在
    @Select("select user_email from users"+
            " where user_email=#{u.email}")
    public Map<String,String> findUserEmail(String email);

    //查找对应邮箱 密码 不匹配则发生错误
    @Select("select user_email,user_password,user_id from users "+
            "where user_email=#{u.email}"+
            "and user_password=#{u.password}")
    public Map<String,String> findLoginInfo(@Param("u")Map<String,String> map);
}
