package com.caiyu.personal_blog.service;

import com.caiyu.personal_blog.mapper.SignupInfoMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

@Service
public class SignupInfoService {
    @Resource
    private SignupInfoMapper signupInfoMapper;

    public boolean checkEmail(Map<String,String> map){
        boolean flag=false;
        Map<String,String> info=null;
        try {
            info=signupInfoMapper.findUserEmail(map.get("email"));
            if(info!=null && info.size()>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //记录日志，写到文件中进行保存
        }
        return flag;
    }

    public boolean doSave(Map<String,String> map){
        boolean flag=false;
        try {
            int r=signupInfoMapper.save(map);
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //记录日志，写到文件中进行保存
        }
        return flag;
    }

    public String doSearchEmail(int user_id){
        return signupInfoMapper.searchEmail(user_id);
    }
}
