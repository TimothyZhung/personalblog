package com.caiyu.personal_blog.service;

import com.caiyu.personal_blog.mapper.BlogInfoMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class BlogInfoService {
    @Resource
    private BlogInfoMapper blogInfoMapper;

    /***********************************   博客相关    **********************************************/

    /*****个人博客只有一个人可以对博客进行操作,将改用户id设为1 对博客进行操作时 后端自动生成该用户id******/
    public List<Map<String,Object>> doFindBlogByUser() {
        List<Map<String, Object>> list = null;
        Map<String,String> map=new HashMap<String,String>();
        map.put("user_id","1");
        try {
            list = blogInfoMapper.findBlogByUserID(Integer.parseInt(map.get("user_id")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public Map<String,Object> doFindDraftBlog(Map<String,String> map){
        Map<String, Object> info = null;
        map.put("user","1");
        try {
            info = blogInfoMapper.findDraftBlog(Integer.parseInt(map.get("user_id")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return info;
    }

    public Map<String,Object> doFindBlogByBlogID(Map<String,String> map){
        Map<String, Object> info = null;
        try {
            info = blogInfoMapper.findBlogByBlogID(Integer.parseInt(map.get("blog_id")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return info;
    }

    public boolean doAddBlog(Map<String,String> map){
        boolean flag=false;
        map.put("user","1");
        map.put("views","0");
        map.put("comments","0");
        map.put("likes","0");
        //选择要添加监控的代码
        //ctrl+alt+t 打开 surround with窗口 选择 try catch
        try {
            int r=blogInfoMapper.addBlog(map);
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //记录日志，写到文件中进行保存
        }
        return flag;
    }
    /*********博客发布之前更改博客 在数据库提前创建id号为1的博客作为草稿博客 每次只更新草稿博客***********/
    public boolean doChangeBlog(Map<String,String> map){
        boolean flag=false;
        map.put("id","1");
        //选择要添加监控的代码
        //ctrl+alt+t 打开 surround with窗口 选择 try catch
        try {
            int r=blogInfoMapper.changeBlog(map);
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //记录日志，写到文件中进行保存
        }
        return flag;
    }

    public boolean doDeleteBlog(Map<String,String> map){
        boolean flag=false;
        try {
            int r=blogInfoMapper.deleteBlog(Integer.parseInt(map.get("blog_id")));
            if(r>0){
                flag=true;
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return flag;
    }

    /***********************************   浏览量相关    **********************************************/

    public int doSearchBlogViews(Map<String,String> map){
        int views=0;
        try {
            views = blogInfoMapper.searchBlogViews(Integer.parseInt(map.get("blog_id")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return views;
    }

    public boolean doUpdateBlogViews(Map<String,String> map){
        boolean flag=false;
        try {
            int r=blogInfoMapper.updateBlogViews(Integer.parseInt(map.get("blog_id")));
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    /***********************************   点赞相关    **********************************************/

    public int doSearchBlogLikes(Map<String,String> map){
        int likes=0;
        try {
            likes = blogInfoMapper.searchBlogLikes(Integer.parseInt(map.get("blog_id")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return likes;
    }

    public boolean doFindIfLiked(Map<String,String> map){
        Map<String,Object> info=new HashMap<String,Object>();
        boolean flag=false;
        try{
            info=blogInfoMapper.findBlogLiker(map);
            if(info!=null){
                flag=true;
            }
        }catch (Exception ex){

        }
        return flag;
    }

    public boolean doAddLikeInfo(Map<String,String> map){
        boolean flag=false;
        try {
            int r=blogInfoMapper.addLikeInfo(map);
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //记录日志，写到文件中进行保存
        }
        return flag;
    }

    public boolean doDeleteLikeInfo(Map<String,String> map){
        boolean flag=false;
        try {
            int r=blogInfoMapper.deleteLikeInfo(map);
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //记录日志，写到文件中进行保存
        }
        return flag;
    }

    public boolean doUpdateBlogLikes(Map<String,String> map){
        boolean flag=false;
        try {
            int r=blogInfoMapper.updateBlogLikes(Integer.parseInt(map.get("blog_id")));
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean doRegretBlogLikes(Map<String,String> map){
        boolean flag=false;
        try {
            int r=blogInfoMapper.regretBlogLikes(Integer.parseInt(map.get("blog_id")));
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    /***********************************   评论相关    **********************************************/

    public int doSearchBlogComments(Map<String,String> map){
        int comments=0;
        try {
            comments = blogInfoMapper.searchBlogComments(Integer.parseInt(map.get("blog_id")));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return comments;
    }

    public boolean doUpdateBlogComments(Map<String,String> map){
        boolean flag=false;
        try {
            int r=blogInfoMapper.updateBlogComments(Integer.parseInt(map.get("blog_id")));
            if(r>0){
                flag=true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }
}
