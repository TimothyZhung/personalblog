package com.caiyu.personal_blog.mapper;

import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface BlogInfoMapper {

    /***********************************   博客相关    **********************************************/


    //通过用户的id查询所有已经发布的文章 即除了博客id号为1的草稿博客 id号为1才能发布文章
    @Select("select * from blogs where user_id=#{user_id} and blog_id<>1 ")
    public List<Map<String,Object>> findBlogByUserID(int user_id);

    //查找博客id为1的草稿博客
    @Select("select * from blogs where user_id=#{user_id} and blog_id=1 ")
    public Map<String,Object> findDraftBlog(int user_id);

    //通过博客id查询博客信息
    @Select("select * from blogs where blog_id=#{blog_id} ")
    public Map<String,Object> findBlogByBlogID(int blog_id);


    //添加博客 blog_content博客正文可以为空 其他都是非空      博客浏览量、评论数、点赞数刚开始均为0
    @Insert("insert into blogs(user_id,blog_title,blog_content,"+
            "blog_time,blog_views,blog_comments,blog_likes,blog_type) "+
            "value(#{blog.user},#{blog.title},#{blog.content},"+
            "#{blog.time},#{blog.views},#{blog.comments},#{blog.likes},#{blog.type})")
    public int addBlog(@Param("blog") Map<String,String> map);


    //根据博客的id号 编辑博客 编辑的是标题和内容 只要传递多个参数的都可以使用map集合进行封装，可以减少方法的参数个数
    @Update("update blogs " +
            "set blog_title=#{blog.title},blog_content=#{blog.content},blog_type=#{blog.type} " +
            "where blog_id=#{blog.id}")
    public int changeBlog(@Param("blog") Map<String,String> map);


    //根据博客的id号 删除该博客
    @Delete("delete from blogs where blog_id=#{blog_id}")
    public int deleteBlog(int id);

    /***********************************   浏览量相关    **********************************************/

    //根据博客id号 查询博客浏览量
    @Select("select blog_views from blogs where blog_id=#{blog_id}")
    public int searchBlogViews(int id);

    //根据博客的id号 更新博客浏览量使其+1
    @Update("update blogs " +
            "set blog_views=blog_views+1 " +
            "where blog_id=#{blog.id}")
    public int updateBlogViews(int id);

    /***********************************   点赞相关    **********************************************/

    //根据博客id号 查询博客点赞数
    @Select("select blog_likes from blogs where blog_id=#{blog_id}")
    public int searchBlogLikes(int id);

    //根据博客id号，查询博客点赞者 对应失败返回null
    @Select("select blog_id,user_id from likes where blog_id=#{like.blog_id} and user_id=#{like.user_id}")
    public Map<String,Object> findBlogLiker(@Param("like") Map<String,String> map);

    //根据博客id号和用户id号 添加点赞信息
    @Insert("insert into likes(blog_id,user_id) value(#{like.blog_id},#{like.user_id})")
    public int addLikeInfo(@Param("like") Map<String,String> map);

    //根据博客id号和用户id号 删除点赞信息
    @Delete("delete from likes where blog_id=#{like.blog_id} and user_id=#{like.user_id}")
    public int deleteLikeInfo(@Param("like") Map<String,String> map);

    //根据博客的id号 更新博客点赞数使其+1
    @Update("update blogs " +
            "set blog_likes=blog_likes+1 " +
            "where blog_id=#{blog.id}")
    public int updateBlogLikes(int id);

    //根据博客的id号 更新博客点赞数使其-1
    @Update("update blogs " +
            "set blog_likes=blog_likes-1 " +
            "where blog_id=#{blog.id}")
    public int regretBlogLikes(int id);

    /***********************************   评论相关    **********************************************/

    //根据博客id号 查询博客评论数
    @Select("select blog_Comments from blogs where blog_id=#{blog_id}")
    public int searchBlogComments(int id);

    //根据博客的id号 更新博客评论数使其+1
    @Update("update blogs " +
            "set blog_Comments=blog_Comments+1 " +
            "where blog_id=#{blog.id}")
    public int updateBlogComments(int id);

}
