package com.caiyu.personal_blog.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import static org.junit.Assert.*;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class CommentInfoServiceTest {

    @Resource
    private CommentInfoService commentInfoService;

    @Test
    public void doFindCommentByUser() {
    }

    @Test
    public void doFindCommentByBlog() {
    }

    @Test
    public void doAddComment() {
    }

    @Test
    public void doDeleteComment() {
    }

    @Test
    public void doSearchCommentLikes() {
    }

    @Test
    public void doUpdateCommentLikes() {
    }
}