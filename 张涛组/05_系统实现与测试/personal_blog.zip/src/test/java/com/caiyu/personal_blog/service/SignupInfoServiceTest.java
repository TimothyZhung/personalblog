package com.caiyu.personal_blog.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest

public class SignupInfoServiceTest {
    @Resource
    SignupInfoService signupInfoService;

    @Test
    public void checkEmail() {
        Map<String,String> map=new HashMap<>();
        map.put("e-mail","admin@123.com");
        assertTrue(signupInfoService.checkEmail(map));
    }

    @Test
    public void doSave() {
        Map<String,String> map=new HashMap<>();
        map.put("e-mail","admin@123.cn");
        map.put("pwd","123456");
        assertTrue(signupInfoService.doSave(map));
    }
}