package com.caiyu.personal_blog.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest

public class LoginInfoServiceTest {
    @Resource
    private LoginInfoService loginInfoService;

    @Test
    public void checkEmail() {
        Map<String,String> map=new HashMap<>();
        map.put("email","admin@123.com");
        assertTrue(loginInfoService.checkEmail(map));
    }

    @Test
    public void checkLogin() {
        Map<String,String> map=new HashMap<>();
        map.put("email","admin@123.com");
        map.put("password","123456");
        Map<String,String> info=loginInfoService.checkLogin(map);
        System.out.println(info);
    }
}