package com.caiyu.personal_blog.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import javax.annotation.Resource;

import java.nio.charset.Charset;

import static org.junit.Assert.*;
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class CommentControllerTest {
    /**
     * 模拟客户端浏览器向服务器发送请求
     */
    @Resource
    private MockMvc mockMvc;
    @Test
    public void findCommentByUser() {
    }

    @Test
    public void findCommentByBlog() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.get("/getcomments")
                        .param("user_id", "2")
                        .param("blog_id","2");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }

    @Test
    public void addComment() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.get("/addcomments")
                        .param("user_id", "4")
                        .param("blog_id","2")
                        .param("comment_time","2020-07-01 12:12:12")
                        .param("comment_content","comment_content")
                        .param("comment_parent_id","1");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }

    @Test
    public void deleteComment() {
    }

    @Test
    public void getCommentLikes() {
    }

    @Test
    public void updateCommentLikes() {
    }
}