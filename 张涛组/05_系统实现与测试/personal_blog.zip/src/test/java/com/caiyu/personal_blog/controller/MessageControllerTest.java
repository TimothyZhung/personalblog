package com.caiyu.personal_blog.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import javax.annotation.Resource;

import java.nio.charset.Charset;

import static org.junit.Assert.*;
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class MessageControllerTest {
    /**
     * 模拟客户端浏览器向服务器发送请求
     */
    @Resource
    private MockMvc mockMvc;

    @Test
    public void addMessage() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.post("/sendmess")
                        .param("user_id","5")
                        .param("message_name","name")
                        .param("message_content","content")
                        .param("message_time","2020-6-30 13:13:13")
                        .param("message_email","visitor@email.com");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }


    @Test
    public void findAllMessage() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.get("/getmess");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }

    @Test
    public void deleteBlog() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.post("/deletemess")
                        .param("message_id","3");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }
}