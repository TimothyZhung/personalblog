package com.caiyu.personal_blog.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class BlogInfoServiceTest {
    @Resource
    private BlogInfoService blogInfoService;

    @Test
    public void doFindBlogByUser() {
        Map<String,String> map=new HashMap<>();
        map.put("user_id","1");
        System.out.println(blogInfoService.doFindBlogByUser());
    }

    @Test
    public void doFindBlogByBlogID() {
        Map<String,String> map=new HashMap<>();
        map.put("user_id","1");
        map.put("blog_id","2");
        System.out.println(blogInfoService.doFindBlogByBlogID(map));
    }

    @Test
    public void doAddBlog() {
        Map<String,String> map=new HashMap<>();
        map.put("id","4");
        map.put("user","1");
        map.put("title","blog_title");
        map.put("content","blog_content");
        map.put("time","2020-6-30 13:13:13");
        map.put("views","0");
        map.put("comments","0");
        map.put("likes","0");
        assertTrue(blogInfoService.doAddBlog(map));
    }

    @Test
    public void doChangeBlog() {
        Map<String,String> map=new HashMap<>();
        map.put("title","blog title");
        map.put("content","blog content");
        map.put("id","4");
        assertTrue(blogInfoService.doChangeBlog(map));
    }

    @Test
    public void doDeleteBlog() {
        Map<String,String> map=new HashMap<>();
        map.put("blog_id","4");
        assertTrue(blogInfoService.doDeleteBlog(map));
    }

    @Test
    public void doSearchBlogViews() {
    }

    @Test
    public void doUpdateBlogViews() {
        Map<String,String> map=new HashMap<>();
        map.put("blog_id","3");
        System.out.println(blogInfoService.doUpdateBlogViews(map));
    }

    @Test
    public void doSearchBlogLikes() {
        Map<String,String> map=new HashMap<>();
        map.put("blog_id","3");
        System.out.println(blogInfoService.doSearchBlogLikes(map));
    }

    @Test
    public void doFindIfLiked() {
        Map<String,String> map=new HashMap<>();
        map.put("blog_id","2");
        map.put("user_id","1");
        //assertTrue(blogInfoService.doFindIfLiked(map));
        System.out.println(blogInfoService.doFindIfLiked(map));
    }

    @Test
    public void doAddLikeInfo(){
        Map<String,String> map=new HashMap<>();
        map.put("blog_id","2");
        map.put("user_id","2");
        assertTrue(blogInfoService.doAddLikeInfo(map));
    }


    @Test
    public void doUpdateBlogLikes() {
        Map<String,String> map=new HashMap<>();
        map.put("blog_id","3");
        System.out.println(blogInfoService.doUpdateBlogLikes(map));
    }

    @Test
    public void doRegretBlogLikes() {
        Map<String,String> map=new HashMap<>();
        map.put("blog_id","3");
        System.out.println(blogInfoService.doRegretBlogLikes(map));
    }

    @Test
    public void doSearchBlogComments() {
    }

    @Test
    public void doUpdateBlogComments() {
    }
}