package com.caiyu.personal_blog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalBlogApplicationTests {

    @Test
    void contextLoads() {
    }

}
