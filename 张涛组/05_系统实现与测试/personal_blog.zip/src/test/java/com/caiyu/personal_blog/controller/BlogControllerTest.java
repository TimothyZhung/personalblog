package com.caiyu.personal_blog.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

import java.nio.charset.Charset;
import java.util.Map;

import static org.junit.Assert.*;
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
public class BlogControllerTest {
    /**
     * 模拟客户端浏览器向服务器发送请求
     */
    @Resource
    private MockMvc mockMvc;
    @Test
    public void findBlogByUser() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.get("/getallblogs");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }

    @Test
    public void getBlogDetails() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.get("/getblog")
                        .param("user_id", "1")
                        .param("blog_id","2");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }

    @Test
    public void addBlog() throws Exception {
        MockHttpServletRequestBuilder builder=
            MockMvcRequestBuilders.post("/upblog")
                    .param("user","1")
                    .param("title","blog_title")
                    .param("content","blog_content")
                    .param("time","2020-6-30 13:13:13")
                    .param("type","1");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }

    @Test
    public void changeBlog() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.post("/saveblog")
                        .param("title","blog_title")
                        .param("content","blogcontent")
                        .param("type","1");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }

    @Test
    public void deleteBlog() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.post("/deleteblog")
                        .param("blog_id","4");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }

    @Test
    public void getBlogViews() {
    }

    @Test
    public void updateBlogViews() {
    }

    @Test
    public void getBlogLikes() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.get("/likes")
                        .param("blog_id", "3");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }

    @Test
    public void changeBlogLikes() throws Exception {
        MockHttpServletRequestBuilder builder=
                MockMvcRequestBuilders.get("/changelikes")
                        .param("blog_id", "3")
                        .param("user_id","1");
        MvcResult rst=mockMvc.perform(builder).andReturn();
        String str=rst.getResponse().getContentAsString(Charset.forName("UTF-8"));
        System.out.println(str);
    }



    @Test
    public void getBlogComments() {
    }

    @Test
    public void updateBlogComments() {
    }
}